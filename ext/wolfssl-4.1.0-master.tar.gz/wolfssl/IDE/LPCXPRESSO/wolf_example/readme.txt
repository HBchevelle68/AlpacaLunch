wolfSSL example

Target board LPC43S37 Xpresso board
The board communicates to the PC terminal through UART0 at 115200.
This example builds the wolfSSL library, test and benchmark examples.
Use 't' to launch the WolfSSL Test
Use 'b' to launch the WolfSSL Benchmark
